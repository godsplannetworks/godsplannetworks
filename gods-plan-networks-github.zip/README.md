# GOD'S PLAN NETWORKS

A responsive, single page website for GOD'S PLAN NETWORKS. The site uses plain HTML, CSS and JavaScript, with no build tools or third party packages.

## Preview locally

Open `index.html` in a web browser.

## Publish with GitHub Pages

1. Create a GitHub repository and add these project files to its root.
2. In the repository, open **Settings**, then **Pages**.
3. Choose deployment from a branch, select the `main` branch and the root folder, then save.
4. GitHub will show the published site address in the Pages settings after deployment.

## Before publishing

Update the sample phone number and email address in `index.html`. The contact form prepares an email in the visitor's email app. It does not save form submissions to a database or send them through a server.

## Project files

* `index.html` contains the complete website, including styles and interactions.
* `.gitignore` excludes common operating system files from version control.
